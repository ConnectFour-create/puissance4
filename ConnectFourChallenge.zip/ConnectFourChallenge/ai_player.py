import numpy as np
import random

class AIPlayer:
    """AI player for Connect Four game"""
    
    def get_move(self, board):
        """
        Determine the best move for the AI
        
        Args:
            board: Current game board
            
        Returns:
            column: The column to place the piece (0-6)
        """
        # For this AI, we'll use a mix of strategy and randomness:
        # 1. Win if possible
        # 2. Block opponent's winning move if needed
        # 3. Prefer center column
        # 4. Otherwise, make a random valid move
        
        # Check for winning move
        for col in range(7):
            if self._is_valid_move(board, col):
                # Try the move
                temp_board = board.copy()
                for row in range(5, -1, -1):
                    if temp_board[row, col] == 0:
                        temp_board[row, col] = 2  # AI is player 2
                        # Check if this move wins
                        if self._check_win_at_position(temp_board, row, col):
                            return col
                        # Undo the move
                        temp_board[row, col] = 0
                        break
        
        # Check for blocking opponent's winning move
        for col in range(7):
            if self._is_valid_move(board, col):
                # Try the move as if the opponent would do it
                temp_board = board.copy()
                for row in range(5, -1, -1):
                    if temp_board[row, col] == 0:
                        temp_board[row, col] = 1  # Player 1
                        # Check if this move would win for the opponent
                        if self._check_win_at_position(temp_board, row, col):
                            return col  # Block it!
                        # Undo the move
                        temp_board[row, col] = 0
                        break
        
        # Prefer center column if available
        if self._is_valid_move(board, 3):
            return 3
        
        # Get all valid moves
        valid_moves = [col for col in range(7) if self._is_valid_move(board, col)]
        
        # Return a random valid move
        return random.choice(valid_moves) if valid_moves else None
    
    def _is_valid_move(self, board, column):
        """Check if a move is valid"""
        return board[0, column] == 0
    
    def _check_win_at_position(self, board, row, column):
        """Check if there's a win at the given position"""
        player = board[row, column]
        
        # Check horizontal
        for c in range(max(0, column-3), min(column+1, 4)):
            if all(board[row, c+i] == player for i in range(4)):
                return True
        
        # Check vertical
        for r in range(max(0, row-3), min(row+1, 3)):
            if all(board[r+i, column] == player for i in range(4)):
                return True
        
        # Check diagonal (down-right)
        for i in range(-3, 1):
            r, c = row+i, column+i
            if 0 <= r < 3 and 0 <= c < 4:
                if all(board[r+j, c+j] == player for j in range(4)):
                    return True
        
        # Check diagonal (up-right)
        for i in range(-3, 1):
            r, c = row-i, column+i
            if 3 <= r < 6 and 0 <= c < 4:
                if all(board[r-j, c+j] == player for j in range(4)):
                    return True
        
        return False
