import numpy as np

class ConnectFourGame:
    """Connect Four game logic implementation"""
    
    def __init__(self):
        """Initialize the game board and state"""
        # Create a 6x7 board filled with zeros (empty cells)
        self.board = np.zeros((6, 7), dtype=int)
        self.current_player = 1  # Player 1 starts
        self.ai_player = None
        
    def make_move(self, column):
        """
        Place a piece in the specified column
        
        Args:
            column: The column to place the piece (0-6)
            
        Returns:
            row: The row where the piece landed
            
        Raises:
            Exception: If the move is invalid
        """
        # Check if column is valid
        if column < 0 or column >= 7:
            raise Exception("Invalid column. Choose a column between 0 and 6.")
        
        # Check if column is full
        if self.board[0, column] != 0:
            raise Exception("Column is full. Choose another column.")
        
        # Find the first empty row from the bottom up
        for row in range(5, -1, -1):
            if self.board[row, column] == 0:
                self.board[row, column] = self.current_player
                return row
    
    def check_win(self, row, column):
        """
        Check if the last move resulted in a win
        
        Args:
            row: The row of the last move
            column: The column of the last move
            
        Returns:
            bool: True if the last move resulted in a win, False otherwise
        """
        player = self.board[row, column]
        
        # Check horizontal
        for c in range(max(0, column-3), min(column+1, 4)):
            if all(self.board[row, c+i] == player for i in range(4)):
                return True
        
        # Check vertical
        for r in range(max(0, row-3), min(row+1, 3)):
            if all(self.board[r+i, column] == player for i in range(4)):
                return True
        
        # Check diagonal (down-right)
        for i in range(-3, 1):
            r, c = row+i, column+i
            if 0 <= r < 3 and 0 <= c < 4:
                if all(self.board[r+j, c+j] == player for j in range(4)):
                    return True
        
        # Check diagonal (up-right)
        for i in range(-3, 1):
            r, c = row-i, column+i
            if 3 <= r < 6 and 0 <= c < 4:
                if all(self.board[r-j, c+j] == player for j in range(4)):
                    return True
        
        return False
    
    def is_board_full(self):
        """Check if the board is full (draw)"""
        return 0 not in self.board[0, :]
    
    def switch_player(self):
        """Switch the current player"""
        self.current_player = 3 - self.current_player  # Switches between 1 and 2
