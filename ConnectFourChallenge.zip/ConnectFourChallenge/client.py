import pygame
import sys
import os
import requests
import json
import time

class ConnectFourClient:
    """
    Pygame client for Connect Four game
    """
    
    # Constants
    WIDTH = 700
    HEIGHT = 600
    CELL_SIZE = 80
    BOARD_OFFSET_X = 85
    BOARD_OFFSET_Y = 100
    SERVER_URL = "http://localhost:5000/api"
    
    # Colors
    BLUE = (0, 0, 255)
    BLACK = (0, 0, 0)
    RED = (255, 0, 0)
    YELLOW = (255, 255, 0)
    WHITE = (255, 255, 255)
    GRAY = (200, 200, 200)
    
    def __init__(self):
        """Initialize the pygame client"""
        pygame.init()
        pygame.mixer.init()
        
        # Set up display
        self.screen = pygame.display.set_mode((self.WIDTH, self.HEIGHT))
        pygame.display.set_caption("Connect Four")
        
        # Set up fonts
        self.title_font = pygame.font.SysFont('Arial', 40, bold=True)
        self.button_font = pygame.font.SysFont('Arial', 30)
        self.status_font = pygame.font.SysFont('Arial', 24)
        
        # Load sound effects
        self.drop_sound = pygame.mixer.Sound('static/sounds/drop.wav')
        self.win_sound = pygame.mixer.Sound('static/sounds/win.wav')
        self.lose_sound = pygame.mixer.Sound('static/sounds/lose.wav')
        
        # Game state
        self.board = [[0 for _ in range(7)] for _ in range(6)]
        self.game_mode = 'vs_ai'  # Default mode
        self.current_player = 1
        self.game_over = False
        self.winner = None
        self.screen_state = 'menu'  # 'menu', 'game', 'stats'
        
        # Animation variables
        self.animations = []  # List of animation data: (piece, target_y, speed)
        
        # Run the game loop
        self.run()
    
    def run(self):
        """Main game loop"""
        running = True
        clock = pygame.time.Clock()
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.handle_click()
            
            # Update animations
            self.update_animations()
            
            # Render the appropriate screen
            if self.screen_state == 'menu':
                self.draw_menu()
            elif self.screen_state == 'game':
                self.draw_game()
            elif self.screen_state == 'stats':
                self.draw_stats()
            
            pygame.display.flip()
            clock.tick(60)
        
        pygame.quit()
        sys.exit()
    
    def handle_click(self):
        """Handle mouse click events"""
        mouse_pos = pygame.mouse.get_pos()
        
        if self.screen_state == 'menu':
            # Check for vs AI button click
            if self.check_button_click((self.WIDTH//2, 200, 300, 60), mouse_pos):
                self.game_mode = 'vs_ai'
                self.start_new_game()
                self.screen_state = 'game'
            
            # Check for 2 player button click
            elif self.check_button_click((self.WIDTH//2, 300, 300, 60), mouse_pos):
                self.game_mode = 'two_player'
                self.start_new_game()
                self.screen_state = 'game'
            
            # Check for statistics button click
            elif self.check_button_click((self.WIDTH//2, 400, 300, 60), mouse_pos):
                self.load_stats()
                self.screen_state = 'stats'
        
        elif self.screen_state == 'game':
            # If game is over, check for play again button
            if self.game_over:
                if self.check_button_click((self.WIDTH//2, 500, 200, 50), mouse_pos):
                    self.start_new_game()
                    return
                
                # Check for back to menu button
                if self.check_button_click((self.WIDTH//2 - 220, 500, 200, 50), mouse_pos):
                    self.screen_state = 'menu'
                    return
            
            # Only process board clicks if it's the player's turn and no animations are running
            if not self.game_over and self.current_player == 1 and not self.animations:
                # Check if click is in board columns
                for col in range(7):
                    column_x = self.BOARD_OFFSET_X + col * self.CELL_SIZE + self.CELL_SIZE // 2
                    column_width = self.CELL_SIZE
                    
                    if column_x - column_width//2 <= mouse_pos[0] <= column_x + column_width//2:
                        self.make_move(col)
                        break
        
        elif self.screen_state == 'stats':
            # Check for back button click
            if self.check_button_click((self.WIDTH//2, 500, 200, 50), mouse_pos):
                self.screen_state = 'menu'
            
            # Check for reset stats button click
            if self.check_button_click((self.WIDTH//2, 400, 200, 50), mouse_pos):
                self.reset_stats()
    
    def check_button_click(self, button_rect, mouse_pos):
        """Check if mouse click is within a button rectangle"""
        x, y, width, height = button_rect
        return (x - width//2 <= mouse_pos[0] <= x + width//2 and
                y - height//2 <= mouse_pos[1] <= y + height//2)
    
    def start_new_game(self):
        """Start a new game"""
        try:
            response = requests.post(
                f"{self.SERVER_URL}/new_game",
                json={'game_mode': self.game_mode}
            )
            data = response.json()
            
            if data['status'] == 'success':
                self.board = data['board']
                self.current_player = data['current_player']
                self.game_over = False
                self.winner = None
                self.animations = []
            else:
                print(f"Error starting new game: {data['message']}")
        except Exception as e:
            print(f"Error communicating with server: {e}")
    
    def make_move(self, column):
        """Make a move in the specified column"""
        try:
            response = requests.post(
                f"{self.SERVER_URL}/make_move",
                json={
                    'column': column,
                    'game_mode': self.game_mode
                }
            )
            data = response.json()
            
            if data['status'] == 'success':
                # Process player's move with animation
                row = data['row']
                self.board[row][column] = data['player']
                self.animate_piece_drop(row, column, data['player'])
                self.drop_sound.play()
                
                # Check for game over after player's move
                if 'game_over' in data:
                    self.handle_game_over(data)
                    return
                
                # Update current player
                self.current_player = data['current_player']
                
                # Process AI move if available
                if 'ai_move' in data:
                    ai_move = data['ai_move']
                    # Wait for player's animation to complete before showing AI move
                    pygame.time.delay(500)
                    self.board[ai_move['row']][ai_move['column']] = ai_move['player']
                    self.animate_piece_drop(ai_move['row'], ai_move['column'], ai_move['player'])
                    self.drop_sound.play()
                    
                    # Check for game over after AI's move
                    if 'game_over' in data:
                        self.handle_game_over(data)
                        return
                    
                    # Update current player after AI move
                    self.current_player = data['current_player']
            else:
                print(f"Error making move: {data['message']}")
        except Exception as e:
            print(f"Error communicating with server: {e}")
    
    def handle_game_over(self, data):
        """Handle game over state"""
        self.game_over = True
        
        if 'draw' in data and data['draw']:
            self.winner = 0  # Draw
        elif 'winner' in data:
            self.winner = data['winner']
            if self.winner == 1:
                self.win_sound.play()
            else:
                self.lose_sound.play()
    
    def animate_piece_drop(self, target_row, column, player):
        """Animate a piece dropping into place"""
        start_y = self.BOARD_OFFSET_Y
        target_y = self.BOARD_OFFSET_Y + target_row * self.CELL_SIZE + self.CELL_SIZE // 2
        
        # Add animation data - (column, player, current_y, target_y)
        self.animations.append([column, player, start_y, target_y])
    
    def update_animations(self):
        """Update all ongoing animations"""
        still_animating = []
        
        for anim in self.animations:
            column, player, current_y, target_y = anim
            
            # Move the piece down
            speed = 15
            current_y += speed
            
            # Check if animation is complete
            if current_y >= target_y:
                current_y = target_y
            else:
                still_animating.append([column, player, current_y, target_y])
        
        self.animations = still_animating
    
    def load_stats(self):
        """Load game statistics from the server"""
        try:
            response = requests.get(f"{self.SERVER_URL.replace('/api', '')}/stats")
            # Parse the HTML to get the stats (simplified approach)
            self.stats_html = response.text
        except Exception as e:
            print(f"Error loading statistics: {e}")
            self.stats_html = "Error loading statistics"
    
    def reset_stats(self):
        """Reset game statistics"""
        try:
            response = requests.post(f"{self.SERVER_URL}/reset_stats")
            data = response.json()
            
            if data['status'] == 'success':
                self.load_stats()
            else:
                print(f"Error resetting stats: {data['message']}")
        except Exception as e:
            print(f"Error communicating with server: {e}")
    
    def draw_menu(self):
        """Draw the main menu screen"""
        self.screen.fill(self.BLACK)
        
        # Draw title
        title = self.title_font.render("CONNECT FOUR", True, self.WHITE)
        self.screen.blit(title, (self.WIDTH//2 - title.get_width()//2, 80))
        
        # Draw buttons
        self.draw_button("Play vs AI", (self.WIDTH//2, 200, 300, 60), self.BLUE)
        self.draw_button("Play 2 Players", (self.WIDTH//2, 300, 300, 60), self.BLUE)
        self.draw_button("Statistics", (self.WIDTH//2, 400, 300, 60), self.BLUE)
    
    def draw_game(self):
        """Draw the game screen"""
        self.screen.fill(self.BLACK)
        
        # Draw game info
        if self.game_mode == 'vs_ai':
            mode_text = "Mode: Player vs AI"
        else:
            mode_text = "Mode: Two Players"
        
        mode_surface = self.status_font.render(mode_text, True, self.WHITE)
        self.screen.blit(mode_surface, (20, 20))
        
        # Draw turn indicator or game result
        if self.game_over:
            if self.winner == 0:
                result_text = "Game Over: Draw!"
                result_color = self.WHITE
            elif self.winner == 1:
                result_text = "Game Over: You Win!"
                result_color = self.RED
            else:
                if self.game_mode == 'vs_ai':
                    result_text = "Game Over: AI Wins!"
                else:
                    result_text = "Game Over: Player 2 Wins!"
                result_color = self.YELLOW
            
            result_surface = self.title_font.render(result_text, True, result_color)
            self.screen.blit(result_surface, (self.WIDTH//2 - result_surface.get_width()//2, 20))
            
            # Draw play again and menu buttons
            self.draw_button("Play Again", (self.WIDTH//2, 500, 200, 50), self.BLUE)
            self.draw_button("Main Menu", (self.WIDTH//2 - 220, 500, 200, 50), self.GRAY)
        else:
            if self.current_player == 1:
                turn_text = "Your Turn" if self.game_mode == 'vs_ai' else "Player 1's Turn"
                turn_color = self.RED
            else:
                turn_text = "AI's Turn" if self.game_mode == 'vs_ai' else "Player 2's Turn"
                turn_color = self.YELLOW
            
            turn_surface = self.status_font.render(turn_text, True, turn_color)
            self.screen.blit(turn_surface, (self.WIDTH - 20 - turn_surface.get_width(), 20))
        
        # Draw the board
        self.draw_board()
        
        # Draw animated pieces
        for column, player, current_y, target_y in self.animations:
            color = self.RED if player == 1 else self.YELLOW
            x = self.BOARD_OFFSET_X + column * self.CELL_SIZE + self.CELL_SIZE // 2
            pygame.draw.circle(self.screen, color, (x, current_y), self.CELL_SIZE // 2 - 5)
    
    def draw_board(self):
        """Draw the Connect Four board"""
        # Draw the blue board frame
        board_width = 7 * self.CELL_SIZE
        board_height = 6 * self.CELL_SIZE
        pygame.draw.rect(
            self.screen, 
            self.BLUE, 
            (self.BOARD_OFFSET_X - 10, self.BOARD_OFFSET_Y - 10, 
             board_width + 20, board_height + 20),
            0, 
            10  # Rounded corners
        )
        
        # Draw the cells
        for row in range(6):
            for col in range(7):
                # Calculate cell position
                x = self.BOARD_OFFSET_X + col * self.CELL_SIZE + self.CELL_SIZE // 2
                y = self.BOARD_OFFSET_Y + row * self.CELL_SIZE + self.CELL_SIZE // 2
                
                # Draw black circle for empty cell
                pygame.draw.circle(self.screen, self.BLACK, (x, y), self.CELL_SIZE // 2 - 5)
                
                # Draw pieces if present (and not being animated)
                piece = self.board[row][col]
                if piece > 0:
                    # Skip drawing if this piece is currently being animated
                    if not any(anim[0] == col and anim[3] == y for anim in self.animations):
                        color = self.RED if piece == 1 else self.YELLOW
                        pygame.draw.circle(self.screen, color, (x, y), self.CELL_SIZE // 2 - 5)
    
    def draw_stats(self):
        """Draw the statistics screen"""
        self.screen.fill(self.BLACK)
        
        # Draw title
        title = self.title_font.render("GAME STATISTICS", True, self.WHITE)
        self.screen.blit(title, (self.WIDTH//2 - title.get_width()//2, 50))
        
        # Parse and display stats from HTML (simplified approach)
        try:
            # Make a direct request to get stats as JSON
            response = requests.get(f"{self.SERVER_URL.replace('/api', '/stats')}")
            
            # Extract stats data from the response
            import re
            ai_wins = re.search(r'vs AI Wins:\s*(\d+)', response.text)
            ai_losses = re.search(r'vs AI Losses:\s*(\d+)', response.text)
            two_player_wins = re.search(r'Two Player Wins:\s*(\d+)', response.text)
            two_player_losses = re.search(r'Two Player Losses:\s*(\d+)', response.text)
            
            # Display AI stats
            y_pos = 150
            self.draw_text("VS AI MODE STATISTICS", (self.WIDTH//2, y_pos), self.BLUE, self.title_font)
            
            y_pos += 50
            if ai_wins and ai_losses:
                wins = int(ai_wins.group(1))
                losses = int(ai_losses.group(1))
                total = wins + losses
                win_pct = (wins / total) * 100 if total > 0 else 0
                
                self.draw_text(f"Wins: {wins}", (self.WIDTH//2, y_pos), self.WHITE, self.status_font)
                y_pos += 30
                self.draw_text(f"Losses: {losses}", (self.WIDTH//2, y_pos), self.WHITE, self.status_font)
                y_pos += 30
                self.draw_text(f"Total Games: {total}", (self.WIDTH//2, y_pos), self.WHITE, self.status_font)
                y_pos += 30
                self.draw_text(f"Win Rate: {win_pct:.1f}%", (self.WIDTH//2, y_pos), self.WHITE, self.status_font)
            else:
                self.draw_text("No data available", (self.WIDTH//2, y_pos), self.WHITE, self.status_font)
            
            # Display Two Player stats
            y_pos += 70
            self.draw_text("TWO PLAYER MODE STATISTICS", (self.WIDTH//2, y_pos), self.YELLOW, self.title_font)
            
            y_pos += 50
            if two_player_wins and two_player_losses:
                wins = int(two_player_wins.group(1))
                losses = int(two_player_losses.group(1))
                total = wins + losses
                win_pct = (wins / total) * 100 if total > 0 else 0
                
                self.draw_text(f"Player 1 Wins: {wins}", (self.WIDTH//2, y_pos), self.WHITE, self.status_font)
                y_pos += 30
                self.draw_text(f"Player 2 Wins: {losses}", (self.WIDTH//2, y_pos), self.WHITE, self.status_font)
                y_pos += 30
                self.draw_text(f"Total Games: {total}", (self.WIDTH//2, y_pos), self.WHITE, self.status_font)
                y_pos += 30
                self.draw_text(f"Player 1 Win Rate: {win_pct:.1f}%", (self.WIDTH//2, y_pos), self.WHITE, self.status_font)
            else:
                self.draw_text("No data available", (self.WIDTH//2, y_pos), self.WHITE, self.status_font)
        
        except Exception as e:
            self.draw_text(f"Error loading statistics: {str(e)}", (self.WIDTH//2, 200), self.WHITE, self.status_font)
        
        # Draw reset stats button
        self.draw_button("Reset Stats", (self.WIDTH//2, 400, 200, 50), self.RED)
        
        # Draw back button
        self.draw_button("Back to Menu", (self.WIDTH//2, 500, 200, 50), self.BLUE)
    
    def draw_button(self, text, rect, color):
        """Draw a button with text"""
        x, y, width, height = rect
        
        # Draw button rectangle with rounded corners
        pygame.draw.rect(
            self.screen, 
            color, 
            (x - width//2, y - height//2, width, height),
            0,  # Fill
            10  # Border radius
        )
        
        # Draw button text
        text_surface = self.button_font.render(text, True, self.WHITE)
        self.screen.blit(
            text_surface, 
            (x - text_surface.get_width()//2, y - text_surface.get_height()//2)
        )
    
    def draw_text(self, text, position, color, font):
        """Draw text at a given position"""
        text_surface = font.render(text, True, color)
        x, y = position
        self.screen.blit(text_surface, (x - text_surface.get_width()//2, y))

if __name__ == "__main__":
    client = ConnectFourClient()
