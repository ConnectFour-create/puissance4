import os
import logging
from flask import Flask, render_template, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Initialize Flask app
class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-connect-four-secret")

# Configure SQLite database (in-memory for simplicity)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///connect_four.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db.init_app(app)

with app.app_context():
    # Import models
    import models
    db.create_all()

# Import game logic
from game_logic import ConnectFourGame
from ai_player import AIPlayer

# Game instances dictionary (session_id -> game)
games = {}

@app.route('/')
def index():
    """Render the main game page"""
    return render_template('index.html')

@app.route('/stats')
def stats():
    """Render the statistics page"""
    from models import GameStatistics
    ai_stats = GameStatistics.query.filter_by(game_type="vs_ai").first()
    two_player_stats = GameStatistics.query.filter_by(game_type="two_player").first()
    
    # Initialize stats if they don't exist
    if not ai_stats:
        ai_stats = GameStatistics(game_type="vs_ai", wins=0, losses=0)
        db.session.add(ai_stats)
    
    if not two_player_stats:
        two_player_stats = GameStatistics(game_type="two_player", wins=0, losses=0)
        db.session.add(two_player_stats)
    
    db.session.commit()
    
    return render_template('stats.html', 
                          ai_stats=ai_stats, 
                          two_player_stats=two_player_stats)

@app.route('/api/new_game', methods=['POST'])
def new_game():
    """Create a new game"""
    game_mode = request.json.get('game_mode', 'vs_ai')
    
    # Generate a unique session ID if not exists
    if 'session_id' not in session:
        import uuid
        session['session_id'] = str(uuid.uuid4())
    
    session_id = session['session_id']
    
    # Create new game instance
    games[session_id] = ConnectFourGame()
    
    if game_mode == 'vs_ai':
        games[session_id].ai_player = AIPlayer()
    
    return jsonify({
        'status': 'success',
        'board': games[session_id].board.tolist(),
        'current_player': games[session_id].current_player
    })

@app.route('/api/make_move', methods=['POST'])
def make_move():
    """Make a move in the game"""
    session_id = session.get('session_id')
    if not session_id or session_id not in games:
        return jsonify({'status': 'error', 'message': 'No active game found'})
    
    column = request.json.get('column')
    game_mode = request.json.get('game_mode', 'vs_ai')
    
    game = games[session_id]
    
    # Try to make the player's move
    try:
        row = game.make_move(column)
        move_result = {
            'status': 'success',
            'row': row,
            'column': column,
            'player': game.current_player  # This is still the player number as the turn hasn't changed yet
        }
        
        # Check for win after player's move
        if game.check_win(row, column):
            move_result['game_over'] = True
            move_result['winner'] = game.current_player
            
            # Update statistics
            from models import GameStatistics
            stats = GameStatistics.query.filter_by(game_type=game_mode).first()
            if stats:
                stats.wins += 1
                db.session.commit()
            
            game.switch_player()  # Switch player before returning
            move_result['current_player'] = game.current_player
            return jsonify(move_result)
        
        # Check for draw
        if game.is_board_full():
            move_result['game_over'] = True
            move_result['draw'] = True
            game.switch_player()  # Switch player before returning
            move_result['current_player'] = game.current_player
            return jsonify(move_result)
        
        # Switch player after the move
        game.switch_player()
        move_result['current_player'] = game.current_player
        
        # If playing against AI and it's AI's turn
        if game_mode == 'vs_ai' and game.current_player == 2:  # Assuming AI is player 2
            ai_column = game.ai_player.get_move(game.board)
            ai_row = game.make_move(ai_column)
            
            move_result['ai_move'] = {
                'row': ai_row,
                'column': ai_column,
                'player': game.current_player  # AI player
            }
            
            # Check for win after AI's move
            if game.check_win(ai_row, ai_column):
                move_result['game_over'] = True
                move_result['winner'] = game.current_player
                
                # Update statistics
                from models import GameStatistics
                stats = GameStatistics.query.filter_by(game_type=game_mode).first()
                if stats:
                    stats.losses += 1
                    db.session.commit()
            
            # Check for draw after AI's move
            elif game.is_board_full():
                move_result['game_over'] = True
                move_result['draw'] = True
            
            # Switch player after AI's move
            game.switch_player()
            move_result['current_player'] = game.current_player
        
        return jsonify(move_result)
    
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

@app.route('/api/reset_stats', methods=['POST'])
def reset_stats():
    """Reset game statistics"""
    try:
        from models import GameStatistics
        
        # Reset AI stats
        ai_stats = GameStatistics.query.filter_by(game_type="vs_ai").first()
        if ai_stats:
            ai_stats.wins = 0
            ai_stats.losses = 0
        
        # Reset two-player stats
        two_player_stats = GameStatistics.query.filter_by(game_type="two_player").first()
        if two_player_stats:
            two_player_stats.wins = 0
            two_player_stats.losses = 0
        
        db.session.commit()
        
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})
