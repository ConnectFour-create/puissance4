from app import db

class GameStatistics(db.Model):
    """Model for storing game statistics"""
    id = db.Column(db.Integer, primary_key=True)
    game_type = db.Column(db.String(20), unique=True, nullable=False)  # 'vs_ai' or 'two_player'
    wins = db.Column(db.Integer, default=0)
    losses = db.Column(db.Integer, default=0)
    
    def __repr__(self):
        return f"<GameStatistics {self.game_type} - W:{self.wins}/L:{self.losses}>"
    
    @property
    def total_games(self):
        return self.wins + self.losses
    
    @property
    def win_percentage(self):
        if self.total_games == 0:
            return 0
        return round((self.wins / self.total_games) * 100, 1)
